package com.company.news.entity;

public interface IDeleteTag
{

    public abstract Integer getDeleteflag();

    public abstract void setDeleteflag(Integer integer);
}
