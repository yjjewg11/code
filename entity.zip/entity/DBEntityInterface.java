package com.company.news.entity;

public interface DBEntityInterface {
    public Object getId();
}
